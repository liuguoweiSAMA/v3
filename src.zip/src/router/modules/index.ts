import auth from './auth'
import front from './front'
import admin from './admin'
import error from './error'

export default [...admin, front, auth, error]
