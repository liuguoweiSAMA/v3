<script setup lang="ts">
import useAuth from '@/composables/useAuth'
import { RouteName } from '@/enum/RouteName'
const { isLogin, logout } = useAuth()
</script>

<template>
  <div>
   abc
  </div>
</template>
