import 'animate.css'

export default () => {}
